void angle_input(float *);
void angle_to_vector(float, float *, float *);
void point_input(float *, float *);
void vector_input(float *, float *);
void vector_normalize(float, float, float *, float *);
float vector_to_angle(float, float);
void rotate_point_by_vector(float, float, float, float, float *, float *);
