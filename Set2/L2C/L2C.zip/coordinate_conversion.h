void polar_to_cartesian(const double, const double, double *, double *);
void cartesian_to_polar(const double, const double, double *, double *);
double degrees(const double);
double radians(const double);